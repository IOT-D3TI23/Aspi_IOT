CREATE DATABASE database_sensor;

USE database_sensor;

CREATE TABLE sensor_data (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    distance FLOAT NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
