<?php
require_once 'config/koneksi.php';
require_once 'includes/function.php';

$sensorData = getSensorData($conn);

if ($conn) {
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IoT Monitoring System</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <div class="container">
        <header class="header">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M2 12h20M2 12l10-10m-10 10l10 10"></path>
            </svg>
            <h1>IoT Monitoring System</h1>
        </header>

        <?php if (!$conn): ?>
        <div class="error-message">
            Terjadi kesalahan saat menghubungkan ke database. Silakan coba beberapa saat lagi.
        </div>
        <?php endif; ?>

        <div class="auto-refresh">
            Halaman akan diperbarui setiap 5 detik
        </div>

        <div class="dashboard-cards">
            <div class="cardqq">
                <div class="card-title">Jarak Terkini</div>
                <div class="card-value">
                    <span class="status-indicator <?php echo getStatusClass($sensorData['latest']); ?>"></span>
                    <?php echo $sensorData['latest']; ?> cm
                </div>
            </div>
            <div class="card">
                <div class="card-title">Rata-rata Jarak</div>
                <div class="card-value"><?php echo $sensorData['average']; ?> cm</div>
            </div>
            <div class="card">
                <div class="card-title">Total Pengukuran</div>
                <div class="card-value"><?php echo $sensorData['total']; ?></div>
            </div>
        </div>

        <div class="data-table">
            <div class="table-header">
                <h2>Riwayat Pembacaan Sensor</h2>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Jarak (cm)</th>
                        <th>Waktu</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($sensorData['readings'])): ?>
                        <tr>
                            <td colspan="3" style="text-align: center;">Tidak ada data</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($sensorData['readings'] as $reading): ?>
                            <tr>
                                <td><?php echo $reading['distance']; ?></td>
                                <td><?php echo $reading['timestamp']; ?></td>
                                <td>
                                    <span class="status-indicator <?php echo getStatusClass($reading['distance']); ?>"></span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        setTimeout(function() {
            window.location.reload();
        }, 5000);
    </script>
</body>
</html>