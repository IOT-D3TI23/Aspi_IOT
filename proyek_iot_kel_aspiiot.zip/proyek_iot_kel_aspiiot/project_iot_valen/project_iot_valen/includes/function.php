<?php
function getSensorData($conn) {
    $data = [
        'latest' => 0,
        'average' => 0,
        'total' => 0,
        'readings' => []
    ];

    if (!$conn) {
        return $data;
    }

    try {
        $sql_latest = "SELECT distance FROM sensor_data ORDER BY timestamp DESC LIMIT 1";
        $result_latest = $conn->query($sql_latest);
        $data['latest'] = $result_latest ? ($result_latest->fetch_assoc()['distance'] ?? 0) : 0;

        $sql_avg = "SELECT AVG(distance) as avg_distance FROM sensor_data";
        $result_avg = $conn->query($sql_avg);
        $data['average'] = $result_avg ? round(($result_avg->fetch_assoc()['avg_distance'] ?? 0), 2) : 0;

        $sql_count = "SELECT COUNT(*) as total FROM sensor_data";
        $result_count = $conn->query($sql_count);
        $data['total'] = $result_count ? ($result_count->fetch_assoc()['total'] ?? 0) : 0;

        $sql = "SELECT distance, timestamp FROM sensor_data ORDER BY timestamp DESC LIMIT 10";
        $result = $conn->query($sql);
        
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $data['readings'][] = $row;
            }
        }
    } catch (Exception $e) {
        error_log("Error fetching sensor data: " . $e->getMessage());
    }

    return $data;
}

function getStatusClass($distance) {
    if ($distance < 50) return 'status-danger';
    if ($distance < 100) return 'status-warning';
    return 'status-good';
}
?>