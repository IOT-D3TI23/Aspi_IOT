<?php
include 'config/koneksi.php';

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['distance'])) {
    $distance = $_POST['distance'];
    
    $sql = "INSERT INTO sensor_data (distance, timestamp) VALUES ('$distance', NOW())";
    
    if ($conn->query($sql) === TRUE) {
        echo "Data saved successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "No data received";
}

$conn->close();
?>
